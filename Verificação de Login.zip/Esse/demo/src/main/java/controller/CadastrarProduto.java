package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;

import java.io.IOException;

@WebServlet("/cadastrarProduto")
public class CadastrarProduto extends HttpServlet {
    Usuario usuario1 = new Usuario("Kate", "12345678910", "Chienne", "K@te", "kate@kate.com");
    Usuario usuario2 = new Usuario("Bob", "9876543201", "Bobao", "b0bB0b", "bob@bob.com");
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String usuario = request.getParameter("Usuario");
        String senha = request.getParameter("Senha");

        if (senha.isEmpty() || usuario.isEmpty()) {
            System.out.println("Preencha todos os campos");
            if (usuario.isEmpty()) {
                System.out.println("O campo 'usuario' nao pode ser deixado em branco.");
            }
            if (senha.isEmpty()) {
                System.out.println("O campo 'senha' nao pode ser deixado em branco.");
            }
            return;
        }

       
        if (usuario1.getSenha().equals(senha)) {
            if (usuario1.getEmail().equals(usuario) || usuario1.getCpf().equals(usuario)) {
                System.out.println("Login válido para Kate");
            } else {
                System.out.println("Usuário inválido para Kate");
            }
        } else {
            System.out.println("Cadastro inválido para Kate");
        }

        // Verificar usuario2
        if (usuario2.getSenha().equals(senha)) {
            if (usuario2.getEmail().equals(usuario) || usuario2.getCpf().equals(usuario)) {
                System.out.println("Login válido para Bob");
            } else {
                System.out.println("Usuário inválido para Bob");
            }
        } else {
            System.out.println("Cadastro inválido para Bob");
        }
    }
}