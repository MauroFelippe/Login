package model;
public class Usuario extends Pessoa {
    private String email;
    private String senha;
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
    public Usuario(String nome, String cpf, String sobrenome,String senha,String email) {
		super(nome, cpf, sobrenome);
        this.senha = senha;
        this.email= email;
        this.setNome(nome);
        this.setSobrenome(sobrenome);
        this.setCpf(cpf);

	}
    
    
    
}
